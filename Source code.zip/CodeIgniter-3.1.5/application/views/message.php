<div class="container col-md-offset-3 col-md-6">
	<div class="row">
		<div class= "container panel panel-default col-md-10 col-md-offset-1">
			<h2>Message</h2>
			<hr/>
			<div class="text-center">
				<p><?= $message ?></p>
			</div>
		</div>
	</div>
</div>